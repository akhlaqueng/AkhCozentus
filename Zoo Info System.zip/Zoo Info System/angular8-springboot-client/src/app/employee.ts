export class Employee {
  id: number;
  AnimalName: string;
  Type: string;
  qty: string;
  active: boolean;
}
